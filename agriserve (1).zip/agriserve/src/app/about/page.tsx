import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AppImage from '@/components/ui/AppImage';

const directorates = [
{
  name: 'Directorate of Animal Resources (DAR)',
  objective: 'To support sustainable animal disease and vector control, market oriented animal production, food quality and safety; for improved food security and household income.',
  image: 'https://www.agriculture.go.ug/wp-content/uploads/2020/04/Agriculture-Uganda.jpg',
  alt: 'Livestock farmers in Uganda managing cattle in a green field',
  color: 'border-l-primary'
},
{
  name: 'Directorate of Crop Resources (DCR)',
  objective: 'To support sustainable, market oriented crop production, pest and disease control, quality and safety of plants and plant products; for improved food security and household income.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/04/crop-resources.jpg',
  alt: 'Ugandan farmers harvesting crops in a well-maintained agricultural field',
  color: 'border-l-secondary'
},
{
  name: 'Directorate of Fisheries Resources (DFR)',
  objective: 'To support sustainable, market oriented fish production, management, development, control quality and safety of fisheries products; for improved food security and household income.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/fisheries.jpg',
  alt: 'Fishermen on Lake Victoria in Uganda with fishing nets and boats',
  color: 'border-l-accent'
},
{
  name: 'Directorate of Agricultural Extension Services (DAES)',
  objective: 'To promote adoption of appropriate information, knowledge, and technological innovations for commercialization of agriculture.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/extension-services.jpg',
  alt: 'Agricultural extension officer training farmers on modern farming techniques',
  color: 'border-l-primary'
}];


const departments = [
{
  name: 'Finance and Administration (F&A)',
  objective: 'To provide financial, administrative, human resource management, development, information and communication systems and services to enable achievement of sector objectives.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/FA1.jpg',
  alt: 'Ministry of Agriculture finance and administration office building in Entebbe Uganda'
},
{
  name: 'Agricultural Infrastructure, Mechanisation and Water (DAIMWAP)',
  objective: 'To support the development of agricultural infrastructure, water for agricultural production and mechanisation to enable achievement of sector objectives.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/DAIMP.jpg',
  alt: 'Agricultural mechanisation equipment and irrigation infrastructure in Uganda'
},
{
  name: 'Agricultural Planning and Development (APD)',
  objective: 'Provide technical support to policy formulation, review and planning processes, design and implementation of programs and projects to enable achievement of sector objectives.',
  image: 'https://www.agriculture.go.ug/wp-content/uploads/2021/10/MAF_6468-150x150.jpg',
  alt: 'Ministry agricultural planning team in a policy development meeting'
},
{
  name: 'Human Resource Management (HRM)',
  objective: 'To initiate and implement human resource policies, plans, systems and procedures for attraction of the requisite human resource that works towards achieving the Ministry objective.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/04/extension-services.jpg',
  alt: 'Ministry of Agriculture human resource management staff at work'
}];


const agencies = [
{ name: 'NARO', full: 'National Agricultural Research Organisation', mandate: 'To coordinate, oversee and guide agricultural research in Uganda.', image: 'http://agriculture.go.ug/wp-content/uploads/2019/04/naro.jpg', alt: 'NARO research scientists conducting agricultural experiments in Uganda laboratory' },
{ name: 'NAGRC&DB', full: 'National Animal Genetic Resources Center & Databank', mandate: 'To play a leading role in the commercialization of animal breeding activities in Uganda.', image: 'http://agriculture.go.ug/wp-content/uploads/2019/04/NAGRCDB.jpg', alt: 'NAGRC&DB animal breeding center with cattle and livestock in Uganda' },
{ name: 'NAADS', full: 'National Agricultural Advisory Services', mandate: 'To provide demand-driven agricultural advisory services to farmers across Uganda.', image: 'https://www.agriculture.go.ug/wp-content/uploads/2020/04/Agriculture-Uganda.jpg', alt: 'NAADS agricultural advisory officers meeting with farmers in rural Uganda' },
{ name: 'DDA', full: 'Dairy Development Authority', mandate: 'To develop, promote and regulate the dairy industry in Uganda.', image: 'http://agriculture.go.ug/wp-content/uploads/2019/04/crop-resources.jpg', alt: 'Dairy Development Authority Uganda dairy farm with cows being milked' },
{ name: 'UCDA', full: 'Uganda Coffee Development Authority', mandate: 'To develop, promote and oversee the quality of coffee produced in Uganda.', image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/fisheries.jpg', alt: 'Uganda Coffee Development Authority coffee farmers harvesting coffee beans' },
{ name: 'COCTU', full: 'Coordination Office for Control of Trypanosomiasis in Uganda', mandate: 'To coordinate and oversee the control of trypanosomiasis (sleeping sickness) in Uganda.', image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/extension-services.jpg', alt: 'COCTU field officers conducting trypanosomiasis disease control in Uganda' },
{ name: 'CDO', full: 'Cotton Development Organisation', mandate: 'To develop, promote and regulate the cotton industry in Uganda.', image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/FA1.jpg', alt: 'Cotton Development Organisation Uganda cotton farmers in a cotton field' }];


export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background overflow-x-hidden">
      <Header />
      {/* Page Hero */}
      <section className="pt-36 pb-20 px-6 lg:px-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-background to-secondary/5" />
        <div className="absolute top-20 right-0 w-96 h-96 rounded-full bg-primary/5 blur-3xl" />
        <div className="max-w-[1400px] mx-auto relative">
          <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-5">
            The Ministry
          </span>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="font-serif-display text-5xl md:text-6xl font-medium text-foreground leading-tight tracking-tight mb-6">
                Ministry of Agriculture,<br />
                <span className="text-primary">Animal Industry</span><br />
                and Fisheries
              </h1>
              <p className="text-muted-foreground text-lg leading-relaxed mb-8 max-w-xl">
                MAAIF is the Government of Uganda ministry responsible for creating an enabling environment for profitable, competitive, dynamic and sustainable agricultural sector. The Ministry guides, regulates and provides technical support to the agricultural sector.
              </p>
              <div className="flex flex-wrap gap-4">
                <div className="px-5 py-3 rounded-2xl bg-primary/10 border border-primary/15">
                  <p className="text-xs text-muted font-semibold uppercase tracking-widest mb-1">Established</p>
                  <p className="text-foreground font-bold text-lg">1962</p>
                </div>
                <div className="px-5 py-3 rounded-2xl bg-accent/10 border border-accent/15">
                  <p className="text-xs text-muted font-semibold uppercase tracking-widest mb-1">Directorates</p>
                  <p className="text-foreground font-bold text-lg">4</p>
                </div>
                <div className="px-5 py-3 rounded-2xl bg-secondary/10 border border-secondary/15">
                  <p className="text-xs text-muted font-semibold uppercase tracking-widest mb-1">Agencies</p>
                  <p className="text-foreground font-bold text-lg">7</p>
                </div>
                <div className="px-5 py-3 rounded-2xl bg-primary/10 border border-primary/15">
                  <p className="text-xs text-muted font-semibold uppercase tracking-widest mb-1">Districts Covered</p>
                  <p className="text-foreground font-bold text-lg">146</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="rounded-3xl overflow-hidden aspect-[4/3] shadow-2xl">
                <AppImage
                  src="https://www.agriculture.go.ug/wp-content/uploads/2020/04/Agriculture-Uganda.jpg"
                  alt="Uganda agricultural landscape with farmers working in lush green fields"
                  width={700}
                  height={525}
                  className="w-full h-full object-cover" />

              </div>
              <div className="absolute -bottom-5 -left-5 bg-white rounded-2xl shadow-xl p-4 border border-border">
                <p className="text-xs text-muted font-semibold uppercase tracking-widest mb-1">Agriculture GDP Share</p>
                <p className="text-2xl font-bold text-primary">24.1%</p>
                <p className="text-xs text-muted-foreground">of Uganda&apos;s GDP</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Vision & Mission */}
      <section className="py-16 px-6 lg:px-16 bg-primary text-white">
        <div className="max-w-[1400px] mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white/10 rounded-3xl p-8 border border-white/15">
              <div className="w-12 h-12 rounded-2xl bg-white/15 flex items-center justify-center mb-5">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              </div>
              <p className="text-white/60 text-xs font-bold uppercase tracking-widest mb-3">Ministry Vision</p>
              <h2 className="font-serif-display text-2xl font-medium leading-snug">
                &ldquo;A competitive, profitable and sustainable agricultural sector&rdquo;
              </h2>
            </div>
            <div className="bg-white/10 rounded-3xl p-8 border border-white/15">
              <div className="w-12 h-12 rounded-2xl bg-white/15 flex items-center justify-center mb-5">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <p className="text-white/60 text-xs font-bold uppercase tracking-widest mb-3">Ministry Mission</p>
              <h2 className="font-serif-display text-2xl font-medium leading-snug">
                &ldquo;To transform subsistence farming to commercial agriculture&rdquo;
              </h2>
            </div>
          </div>
        </div>
      </section>
      {/* Mandate */}
      <section className="py-20 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 items-start">
            <div className="lg:col-span-2">
              <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-4">
                Our Mandate
              </span>
              <h2 className="font-serif-display text-4xl font-medium text-foreground leading-tight mb-6">
                Mandate &amp; Functions
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                The Ministry of Agriculture, Animal Industry and Fisheries (MAAIF) is mandated to support the transformation of the agricultural sector from subsistence to commercial agriculture.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                MAAIF provides technical support, regulatory oversight, and policy guidance to ensure a productive, competitive and sustainable agricultural sector that contributes to food security and economic growth.
              </p>
            </div>
            <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
              { title: 'Policy Formulation', desc: 'Develop and review agricultural policies, strategies and investment plans aligned with national development goals.' },
              { title: 'Regulatory Oversight', desc: 'Regulate and inspect agricultural inputs, products, and services to ensure quality and safety standards.' },
              { title: 'Research Coordination', desc: 'Coordinate agricultural research and technology development through NARO and partner institutions.' },
              { title: 'Extension Services', desc: 'Promote adoption of improved agricultural technologies through the national extension system.' },
              { title: 'Trade Facilitation', desc: 'Facilitate import and export of agricultural products through certification and compliance services.' },
              { title: 'Sector Planning', desc: 'Plan and coordinate agricultural development programs and projects across all sub-sectors.' }]?.
              map((item) =>
              <div key={item?.title} className="p-5 rounded-2xl bg-card border border-border hover:border-primary/30 transition-colors">
                  <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                    <svg className="w-4 h-4 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="font-semibold text-foreground text-sm mb-1.5">{item?.title}</h3>
                  <p className="text-muted-foreground text-xs leading-relaxed">{item?.desc}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
      {/* Minister's Message */}
      <section className="py-20 px-6 lg:px-16 bg-gradient-to-br from-primary/5 to-background">
        <div className="max-w-[1400px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="rounded-3xl overflow-hidden aspect-[3/4] max-w-sm mx-auto shadow-2xl">
                <AppImage
                  src="https://www.agriculture.go.ug/wp-content/uploads/bb/cache/BLA_1927-264x300-circle.jpg"
                  alt="Hon. Frank Tumwebaze, Minister of Agriculture Animal Industry and Fisheries Uganda"
                  width={400}
                  height={533}
                  className="w-full h-full object-cover" />

              </div>
              <div className="absolute -bottom-4 -right-4 bg-primary text-white rounded-2xl p-4 shadow-xl max-w-[200px]">
                <p className="font-bold text-sm">Hon. Frank Tumwebaze</p>
                <p className="text-white/70 text-xs mt-0.5">Minister of Agriculture, Animal Industry and Fisheries</p>
              </div>
            </div>
            <div>
              <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-5">
                Minister&apos;s Message
              </span>
              <h2 className="font-serif-display text-4xl font-medium text-foreground leading-tight mb-6">
                Welcome to the National Agricultural Sector Portal
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  Welcome to the official website of the Ministry of Agriculture, Animal Industry and Fisheries which doubles as the National Agricultural Sector Portal for the Republic of Uganda.
                </p>
                <p>
                  Visitors are welcome to explore this communication channel of the Ministry which complements stakeholder engagements, agricultural extension, publications and media features in showcasing work done within the guidance of the Vision of &ldquo;A Competitive, Profitable and Sustainable Agricultural Sector&rdquo; and Mission &ldquo;To Transform Subsistence Farming into Commercial Agriculture.&rdquo;
                </p>
                <p>
                  In this term, we will spend more time with the farmers in the fields than in conferences. The Ministry recognizes and prioritizes strategic communication and the use of modern online platforms to reach our various audiences.
                </p>
                <p>
                  The Ministry Offices across the country are also open to the general public during official working hours for any consultation regarding the agricultural sector and related services.
                </p>
              </div>
              <p className="mt-6 font-semibold text-foreground italic">For God and my Country.</p>
            </div>
          </div>
        </div>
      </section>
      {/* Directorates */}
      <section className="py-20 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <div className="mb-12">
            <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-4">
              Structure
            </span>
            <h2 className="font-serif-display text-4xl font-medium text-foreground leading-tight">
              Directorates
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {directorates?.map((dir) =>
            <div key={dir?.name} className={`rounded-3xl overflow-hidden border border-border bg-card flex flex-col md:flex-row border-l-4 ${dir?.color} hover:shadow-lg transition-shadow`}>
                <div className="md:w-48 flex-shrink-0 h-48 md:h-auto overflow-hidden">
                  <AppImage
                  src={dir?.image}
                  alt={dir?.alt}
                  width={192}
                  height={192}
                  className="w-full h-full object-cover" />

                </div>
                <div className="p-6 flex flex-col justify-center">
                  <h3 className="font-semibold text-foreground text-base mb-2 leading-tight">{dir?.name}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{dir?.objective}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
      {/* Departments */}
      <section className="py-20 px-6 lg:px-16 bg-gradient-to-b from-background to-primary/5">
        <div className="max-w-[1400px] mx-auto">
          <div className="mb-12">
            <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-4">
              Departments
            </span>
            <h2 className="font-serif-display text-4xl font-medium text-foreground leading-tight">
              Ministry Departments
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {departments?.map((dept) =>
            <div key={dept?.name} className="rounded-3xl overflow-hidden border border-border bg-card hover:shadow-lg transition-all hover:-translate-y-1 group">
                <div className="h-40 overflow-hidden">
                  <AppImage
                  src={dept?.image}
                  alt={dept?.alt}
                  width={400}
                  height={160}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />

                </div>
                <div className="p-5">
                  <h3 className="font-semibold text-foreground text-sm mb-2 leading-tight">{dept?.name}</h3>
                  <p className="text-muted-foreground text-xs leading-relaxed">{dept?.objective}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
      {/* Agencies */}
      <section className="py-20 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <div className="mb-12">
            <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-4">
              Semi-Autonomous Bodies
            </span>
            <h2 className="font-serif-display text-4xl font-medium text-foreground leading-tight">
              Ministry Agencies
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {agencies?.map((agency) =>
            <div key={agency?.name} className="rounded-3xl overflow-hidden border border-border bg-card hover:shadow-lg transition-all hover:-translate-y-1 group">
                <div className="h-36 overflow-hidden">
                  <AppImage
                  src={agency?.image}
                  alt={agency?.alt}
                  width={400}
                  height={144}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />

                </div>
                <div className="p-5">
                  <span className="inline-block px-2.5 py-1 rounded-lg bg-primary/10 text-primary text-xs font-bold mb-2">{agency?.name}</span>
                  <h3 className="font-semibold text-foreground text-sm mb-1.5 leading-tight">{agency?.full}</h3>
                  <p className="text-muted-foreground text-xs leading-relaxed">{agency?.mandate}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
      {/* Contact CTA */}
      <section className="py-16 px-6 lg:px-16 bg-primary text-white">
        <div className="max-w-[1400px] mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="font-serif-display text-3xl font-medium mb-2">Visit Our Offices</h2>
            <p className="text-white/70 leading-relaxed">
              Plot 16-18, Lugard Avenue, Entebbe, Uganda · P.O Box 102, Entebbe · Tel: 041 4320004
            </p>
          </div>
          <a
            href="mailto:info@agriculture.go.ug"
            className="flex-shrink-0 px-6 py-3 rounded-full bg-white text-primary font-semibold text-sm hover:bg-white/90 transition-colors">

            info@agriculture.go.ug
          </a>
        </div>
      </section>
      <Footer />
    </main>);

}