import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const categories = [
  {
    id: 'policies',
    label: 'Acts, Policies & Strategies',
    icon: '📋',
    docs: [
      { title: 'The National Agriculture Policy (NAP)', year: '2013', type: 'Policy', size: '2.4 MB' },
      { title: 'Agriculture Sector Development Strategy and Investment Plan (ASDSIP)', year: '2015–2020', type: 'Strategy', size: '5.1 MB' },
      { title: 'Animal Feeds Act 2024', year: '2024', type: 'Act', size: '1.2 MB' },
      { title: 'Veterinary Practitioners Act 2023', year: '2023', type: 'Act', size: '0.9 MB' },
      { title: 'Plant Protection Act (Cap 31)', year: '2000', type: 'Act', size: '1.8 MB' },
      { title: 'Fisheries and Aquaculture Act 2022', year: '2022', type: 'Act', size: '2.1 MB' },
    ],
  },
  {
    id: 'sector-reports',
    label: 'Sector Performance Reports',
    icon: '📊',
    docs: [
      { title: 'Agriculture Sector Annual Performance Report 2024/25', year: '2025', type: 'Report', size: '8.3 MB' },
      { title: 'Agriculture Sector Annual Performance Report 2023/24', year: '2024', type: 'Report', size: '7.9 MB' },
      { title: 'Agriculture Sector Annual Performance Report 2022/23', year: '2023', type: 'Report', size: '7.2 MB' },
      { title: 'Uganda Agriculture Sector Review 2022', year: '2022', type: 'Review', size: '6.5 MB' },
      { title: 'National Food and Nutrition Policy Implementation Report', year: '2024', type: 'Report', size: '4.2 MB' },
      { title: 'MAAIF Budget Framework Paper 2025/26', year: '2025', type: 'Budget', size: '3.1 MB' },
    ],
  },
  {
    id: 'crop',
    label: 'Crop Sub-Sector Publications',
    icon: '🌾',
    docs: [
      { title: 'National Crop Variety List 2024', year: '2024', type: 'Reference', size: '3.8 MB' },
      { title: 'Integrated Pest Management Guidelines', year: '2023', type: 'Guidelines', size: '4.5 MB' },
      { title: 'Fall Armyworm Management Guide', year: '2022', type: 'Guide', size: '2.2 MB' },
      { title: 'Banana Xanthomonas Wilt (BXW) Control Manual', year: '2021', type: 'Manual', size: '1.9 MB' },
      { title: 'Maize Production Guide for Uganda', year: '2023', type: 'Guide', size: '2.7 MB' },
      { title: 'Coffee Production and Quality Standards', year: '2024', type: 'Standards', size: '3.3 MB' },
    ],
  },
  {
    id: 'animal',
    label: 'Animal Sub-Sector Publications',
    icon: '🐄',
    docs: [
      { title: 'National Livestock Census Report 2021', year: '2021', type: 'Report', size: '9.1 MB' },
      { title: 'Rabies Control and Prevention Guidelines', year: '2023', type: 'Guidelines', size: '1.5 MB' },
      { title: 'Antimicrobial Resistance (AMR) Action Plan', year: '2022', type: 'Plan', size: '2.8 MB' },
      { title: 'Foot and Mouth Disease (FMD) Control Strategy', year: '2024', type: 'Strategy', size: '2.1 MB' },
      { title: 'Dairy Development Guidelines for Smallholders', year: '2023', type: 'Guidelines', size: '3.4 MB' },
      { title: 'Poultry Production Manual', year: '2022', type: 'Manual', size: '2.6 MB' },
    ],
  },
  {
    id: 'fisheries',
    label: 'Fisheries Publications',
    icon: '🐟',
    docs: [
      { title: 'National Fisheries Policy 2004', year: '2004', type: 'Policy', size: '1.7 MB' },
      { title: 'Aquaculture Development Strategy 2020–2025', year: '2020', type: 'Strategy', size: '3.2 MB' },
      { title: 'Lake Victoria Fisheries Frame Survey Report', year: '2023', type: 'Report', size: '5.8 MB' },
      { title: 'Fish Quality and Safety Standards for Export', year: '2022', type: 'Standards', size: '2.4 MB' },
      { title: 'Cage Fish Farming Guidelines', year: '2021', type: 'Guidelines', size: '1.9 MB' },
      { title: 'Inland Fisheries Management Plan', year: '2023', type: 'Plan', size: '4.1 MB' },
    ],
  },
  {
    id: 'extension',
    label: 'Agricultural Extension Guidelines',
    icon: '👨‍🌾',
    docs: [
      { title: 'National Agricultural Extension Policy 2016', year: '2016', type: 'Policy', size: '2.3 MB' },
      { title: 'Farmer Group Formation and Management Guide', year: '2022', type: 'Guide', size: '1.8 MB' },
      { title: 'Agricultural Mechanisation Strategy 2021–2030', year: '2021', type: 'Strategy', size: '3.7 MB' },
      { title: 'Training of Trainers (ToT) Manual for Extension Workers', year: '2023', type: 'Manual', size: '4.2 MB' },
      { title: 'Irrigation Development Guidelines', year: '2022', type: 'Guidelines', size: '2.9 MB' },
      { title: 'Post-Harvest Handling and Storage Manual', year: '2023', type: 'Manual', size: '3.1 MB' },
    ],
  },
];

const typeColors: Record<string, string> = {
  Policy: 'bg-primary/10 text-primary',
  Strategy: 'bg-secondary/10 text-secondary',
  Act: 'bg-red-100 text-red-700',
  Report: 'bg-sky-100 text-sky-700',
  Review: 'bg-purple-100 text-purple-700',
  Budget: 'bg-accent/10 text-accent',
  Reference: 'bg-emerald-100 text-emerald-700',
  Guidelines: 'bg-teal-100 text-teal-700',
  Guide: 'bg-green-100 text-green-700',
  Manual: 'bg-orange-100 text-orange-700',
  Standards: 'bg-indigo-100 text-indigo-700',
  Plan: 'bg-pink-100 text-pink-700',
};

export default function LibraryPage() {
  return (
    <main className="min-h-screen bg-background overflow-x-hidden">
      <Header />

      {/* Page Hero */}
      <section className="pt-36 pb-16 px-6 lg:px-16 bg-gradient-to-b from-primary/5 to-background">
        <div className="max-w-[1400px] mx-auto">
          <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-4">
            Knowledge Centre
          </span>
          <h1 className="font-serif-display text-5xl md:text-6xl font-medium text-foreground leading-tight tracking-tight mb-4">
            Library &amp; Publications
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl leading-relaxed">
            Access the full collection of MAAIF publications including Acts, policies, strategies, sector performance reports, technical guidelines, and research documents.
          </p>
          <div className="flex flex-wrap gap-4 mt-8">
            {[
              { label: 'Total Documents', value: '200+' },
              { label: 'Policy Documents', value: '45' },
              { label: 'Technical Guides', value: '80+' },
              { label: 'Annual Reports', value: '30+' },
            ].map((stat) => (
              <div key={stat.label} className="px-5 py-3 rounded-2xl bg-card border border-border">
                <p className="text-xl font-bold text-primary">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Document Categories */}
      <section className="py-16 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto space-y-12">
          {categories.map((cat) => (
            <div key={cat.id}>
              <div className="flex items-center gap-3 mb-6">
                <span className="text-2xl">{cat.icon}</span>
                <h2 className="font-serif-display text-2xl font-medium text-foreground">{cat.label}</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {cat.docs.map((doc) => (
                  <div key={doc.title} className="flex items-start gap-4 p-5 rounded-2xl bg-card border border-border hover:border-primary/30 hover:shadow-sm transition-all group">
                    <div className="w-10 h-12 rounded-xl bg-primary/8 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/15 transition-colors">
                      <svg className="w-5 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-foreground text-sm leading-tight mb-1.5 line-clamp-2">{doc.title}</h3>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`px-2 py-0.5 rounded-md text-xs font-semibold ${typeColors[doc.type] || 'bg-muted/20 text-muted'}`}>
                          {doc.type}
                        </span>
                        <span className="text-muted text-xs">{doc.year}</span>
                        <span className="text-muted text-xs">· {doc.size}</span>
                      </div>
                    </div>
                    <a
                      href="#"
                      className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-all flex-shrink-0 mt-0.5"
                      aria-label={`Download ${doc.title}`}
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Procurement Plans */}
      <section className="py-16 px-6 lg:px-16 bg-gradient-to-b from-background to-primary/5">
        <div className="max-w-[1400px] mx-auto">
          <div className="rounded-3xl bg-primary text-white p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h2 className="font-serif-display text-3xl font-medium mb-3">Procurement Plans</h2>
              <p className="text-white/70 leading-relaxed max-w-lg">
                Access MAAIF&apos;s annual procurement plans, tender dossiers, and terms of reference for ongoing and upcoming procurement activities.
              </p>
            </div>
            <div className="flex flex-col gap-3 flex-shrink-0">
              <a href="#" className="px-6 py-3 rounded-full bg-white text-primary font-semibold text-sm hover:bg-white/90 transition-colors text-center">
                Procurement Plan 2025/26
              </a>
              <a href="#" className="px-6 py-3 rounded-full border border-white/30 text-white font-semibold text-sm hover:bg-white/10 transition-colors text-center">
                View All Procurement
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
