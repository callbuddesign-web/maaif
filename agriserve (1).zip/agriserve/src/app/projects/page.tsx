import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AppImage from '@/components/ui/AppImage';

const featuredProject = {
  title: 'Uganda Climate Smart Agricultural Transformation Project (UCSATP)',
  status: 'Active',
  budget: 'USD 150 Million',
  funder: 'World Bank / IDA',
  duration: '2023 – 2028',
  districts: '60 Districts',
  description: 'The UCSATP aims to increase agricultural productivity and build climate resilience for smallholder farmers across Uganda. The project supports adoption of climate-smart technologies, improved seed systems, irrigation development, and market access for over 500,000 farming households.',
  objectives: [
  'Increase crop and livestock productivity by 30% in target areas',
  'Expand irrigated area by 15,000 hectares',
  'Improve access to certified seeds and inputs for 500,000 farmers',
  'Strengthen early warning systems for climate-related risks',
  'Develop agro-processing and market linkages'],

  image: 'https://www.agriculture.go.ug/wp-content/uploads/2021/06/FROST-20-of-149.jpg',
  alt: 'Farmers in Uganda benefiting from climate smart agricultural transformation project activities'
};

const projects = [
{
  id: 'umsfsn',
  title: 'Uganda Multi-Sector Food Security and Nutrition Project',
  sector: 'Food Security',
  status: 'Active',
  budget: 'USD 75 Million',
  funder: 'World Bank',
  duration: '2022 – 2027',
  description: 'Addresses food insecurity and malnutrition through integrated interventions in agriculture, health, and social protection across 20 districts.',
  image: 'https://www.agriculture.go.ug/wp-content/uploads/2020/11/ghfk.jpg',
  alt: 'Ugandan families receiving food security support and nutrition education in rural communities'
},
{
  id: 'acdp',
  title: 'Agriculture Cluster Development Project (ACDP)',
  sector: 'Crop Production',
  status: 'Active',
  budget: 'USD 150 Million',
  funder: 'World Bank / IFAD',
  duration: '2018 – 2025',
  description: 'Supports commercialization of smallholder agriculture through cluster-based approaches for maize, rice, beans, cassava, and coffee value chains.',
  image: 'https://www.agriculture.go.ug/wp-content/uploads/2020/11/fgh.jpg',
  alt: 'Smallholder farmers in Uganda participating in agriculture cluster development project activities'
},
{
  id: 'rplrp',
  title: 'Regional Pastoral Livelihoods Resilience Project (RPLRP)',
  sector: 'Livestock',
  status: 'Completed',
  budget: 'USD 50 Million',
  funder: 'World Bank',
  duration: '2014 – 2022',
  description: 'Improved livelihoods and resilience of pastoral and agro-pastoral communities in the Karamoja sub-region through livestock development and natural resource management.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/projectsg-1.jpg',
  alt: 'Pastoral communities in Karamoja Uganda with improved livestock under RPLRP project'
},
{
  id: 'pesca',
  title: 'PESCA — Fisheries & Aquaculture Value Chain Project',
  sector: 'Fisheries',
  status: 'Active',
  budget: 'USD 30 Million',
  funder: 'European Union',
  duration: '2021 – 2026',
  description: 'Strengthens the fisheries and aquaculture value chain in Uganda through improved production, quality standards, and market access for fish farmers and processors.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/fisheries.jpg',
  alt: 'Fish farmers in Uganda participating in PESCA aquaculture value chain development project'
},
{
  id: 'nosp',
  title: 'National Oil Seed Project (NOSP)',
  sector: 'Crop Production',
  status: 'Active',
  budget: 'USD 25 Million',
  funder: 'IFAD',
  duration: '2020 – 2026',
  description: 'Promotes production and commercialization of oil seeds (sunflower, soybean, sesame) to improve farmer incomes and reduce Uganda\'s edible oil import bill.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/04/crop-resources.jpg',
  alt: 'Ugandan farmers harvesting sunflower crops under the National Oil Seed Project'
},
{
  id: 'nopp',
  title: 'National Oil Palm Project (NOPP)',
  sector: 'Crop Production',
  status: 'Active',
  budget: 'USD 120 Million',
  funder: 'Government of Uganda / BIDCO',
  duration: '2003 – Ongoing',
  description: 'Develops oil palm production in the Kalangala and Buvuma islands to produce palm oil for domestic consumption and export, benefiting over 3,000 smallholder farmers.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/project3.jpg',
  alt: 'Oil palm plantation in Kalangala Uganda under the National Oil Palm Project'
},
{
  id: 'avcp',
  title: 'Agricultural Value Chain Development Project (AVCP)',
  sector: 'Value Chains',
  status: 'Active',
  budget: 'USD 45 Million',
  funder: 'African Development Bank',
  duration: '2022 – 2027',
  description: 'Develops competitive agricultural value chains for selected commodities including coffee, tea, vanilla, and horticulture to increase export earnings.',
  image: 'https://www.agriculture.go.ug/wp-content/uploads/2020/04/Agriculture-Uganda.jpg',
  alt: 'Agricultural value chain development activities in Uganda including coffee and horticulture processing'
},
{
  id: 'pride2',
  title: 'PRiDe II — Promoting Rice Development in Uganda',
  sector: 'Crop Production',
  status: 'Active',
  budget: 'USD 18 Million',
  funder: 'JICA / Government of Japan',
  duration: '2021 – 2026',
  description: 'Supports rice production and productivity improvement in Eastern Uganda through improved varieties, irrigation, and post-harvest technologies.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/04/extension-services.jpg',
  alt: 'Rice farmers in Eastern Uganda participating in PRiDe II rice development project activities'
}];


const sectorColors: Record<string, string> = {
  'Food Security': 'bg-primary/10 text-primary',
  'Crop Production': 'bg-secondary/10 text-secondary',
  'Livestock': 'bg-accent/10 text-accent',
  'Fisheries': 'bg-sky-100 text-sky-700',
  'Value Chains': 'bg-purple-100 text-purple-700'
};

export default function ProjectsPage() {
  return (
    <main className="min-h-screen bg-background overflow-x-hidden">
      <Header />

      {/* Page Hero */}
      <section className="pt-36 pb-16 px-6 lg:px-16 bg-gradient-to-b from-primary/5 to-background">
        <div className="max-w-[1400px] mx-auto">
          <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-4">
            Development Programs
          </span>
          <h1 className="font-serif-display text-5xl md:text-6xl font-medium text-foreground leading-tight tracking-tight mb-4">
            MAAIF Projects
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl leading-relaxed mb-8">
            The Ministry of Agriculture, Animal Industry and Fisheries, in cooperation with international partners, is implementing agricultural development projects to operationalize the Agriculture Sector Development Strategy and Investment Plan.
          </p>
          <div className="flex flex-wrap gap-4">
            {[
            { label: 'Active Projects', value: '40+' },
            { label: 'Total Investment', value: 'UGX 2.4T' },
            { label: 'Districts Covered', value: '112' },
            { label: 'Farmers Reached', value: '1.2M+' }].
            map((stat) =>
            <div key={stat.label} className="px-5 py-3 rounded-2xl bg-card border border-border">
                <p className="text-xl font-bold text-primary">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Featured Project */}
      <section className="py-12 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <div className="rounded-3xl overflow-hidden border border-border bg-card shadow-lg grid grid-cols-1 lg:grid-cols-2">
            <div className="h-72 lg:h-auto overflow-hidden">
              <AppImage
                src={featuredProject.image}
                alt={featuredProject.alt}
                width={700}
                height={500}
                className="w-full h-full object-cover" />

            </div>
            <div className="p-8 lg:p-10">
              <div className="flex items-center gap-2 mb-4">
                <span className="px-3 py-1 rounded-full bg-primary text-white text-xs font-semibold">Featured Project</span>
                <span className="px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-semibold">● {featuredProject.status}</span>
              </div>
              <h2 className="font-serif-display text-2xl font-medium text-foreground leading-tight mb-4">
                {featuredProject.title}
              </h2>
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">{featuredProject.description}</p>
              <div className="grid grid-cols-2 gap-3 mb-6">
                {[
                { label: 'Budget', value: featuredProject.budget },
                { label: 'Funder', value: featuredProject.funder },
                { label: 'Duration', value: featuredProject.duration },
                { label: 'Coverage', value: featuredProject.districts }].
                map((item) =>
                <div key={item.label} className="p-3 rounded-xl bg-primary/5 border border-primary/10">
                    <p className="text-xs text-muted font-semibold uppercase tracking-wide mb-0.5">{item.label}</p>
                    <p className="text-sm font-semibold text-foreground">{item.value}</p>
                  </div>
                )}
              </div>
              <ul className="space-y-2">
                {featuredProject.objectives.slice(0, 3).map((obj, i) =>
                <li key={i} className="flex items-start gap-2.5 text-sm text-foreground">
                    <span className="mt-0.5 w-4 h-4 rounded-full bg-primary/15 text-primary flex items-center justify-center flex-shrink-0">
                      <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                      </svg>
                    </span>
                    {obj}
                  </li>
                )}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* All Projects */}
      <section className="py-12 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <h2 className="font-serif-display text-3xl font-medium text-foreground mb-8">All Development Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {projects.map((project) =>
            <article key={project.id} className="rounded-3xl overflow-hidden border border-border bg-card hover:shadow-lg transition-all hover:-translate-y-1 group flex flex-col">
                <div className="h-44 overflow-hidden flex-shrink-0">
                  <AppImage
                  src={project.image}
                  alt={project.alt}
                  width={400}
                  height={176}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />

                </div>
                <div className="p-5 flex flex-col flex-1">
                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${sectorColors[project.sector] || 'bg-muted/20 text-muted'}`}>
                      {project.sector}
                    </span>
                    <span className={`px-2 py-0.5 rounded-md text-xs font-semibold ${project.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-muted/20 text-muted'}`}>
                      {project.status === 'Active' ? '● Active' : project.status}
                    </span>
                  </div>
                  <h3 className="font-semibold text-foreground text-sm leading-tight mb-2 flex-1">{project.title}</h3>
                  <p className="text-muted-foreground text-xs leading-relaxed mb-4 line-clamp-3">{project.description}</p>
                  <div className="grid grid-cols-2 gap-2 mt-auto">
                    <div className="p-2 rounded-lg bg-primary/5">
                      <p className="text-xs text-muted">Budget</p>
                      <p className="text-xs font-semibold text-foreground">{project.budget}</p>
                    </div>
                    <div className="p-2 rounded-lg bg-primary/5">
                      <p className="text-xs text-muted">Duration</p>
                      <p className="text-xs font-semibold text-foreground">{project.duration}</p>
                    </div>
                  </div>
                </div>
              </article>
            )}
          </div>
        </div>
      </section>

      {/* Partners */}
      <section className="py-16 px-6 lg:px-16 bg-gradient-to-b from-background to-primary/5">
        <div className="max-w-[1400px] mx-auto">
          <div className="text-center mb-10">
            <h2 className="font-serif-display text-3xl font-medium text-foreground mb-3">Development Partners</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">MAAIF works with a range of international development partners to finance and implement agricultural development programs.</p>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            {['World Bank / IDA', 'African Development Bank', 'IFAD', 'European Union', 'JICA (Japan)', 'FAO', 'USAID', 'GIZ (Germany)', 'DANIDA (Denmark)', 'DFID / FCDO (UK)'].map((partner) =>
            <span key={partner} className="px-5 py-2.5 rounded-full bg-card border border-border text-foreground text-sm font-medium hover:border-primary/30 hover:text-primary transition-colors">
                {partner}
              </span>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </main>);

}