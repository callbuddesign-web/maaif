'use client';
import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AppImage from '@/components/ui/AppImage';

const pressReleases = [
{
  id: 1,
  title: 'MAAIF Launches Uganda Climate Smart Agricultural Transformation Project (UCSATP)',
  date: 'April 15, 2026',
  category: 'Press Release',
  excerpt: 'The Ministry of Agriculture, Animal Industry and Fisheries has officially launched the Uganda Climate Smart Agricultural Transformation Project, a USD 150 million initiative funded by the World Bank to support climate-resilient agriculture across 60 districts.',
  image: 'https://www.agriculture.go.ug/wp-content/uploads/2021/06/FROST-20-of-149.jpg',
  alt: 'MAAIF officials at the launch of Uganda Climate Smart Agricultural Transformation Project ceremony'
},
{
  id: 2,
  title: 'Minister Tumwebaze Pledges Hands-On Approach in Agriculture Sector',
  date: 'March 28, 2026',
  category: 'Press Release',
  excerpt: 'Hon. Frank Tumwebaze, the Minister of Agriculture, Animal Industry and Fisheries, has promised to apply a proactive approach through directly engaging farmers on ministry policies. "In this term, we will spend more time with the farmers in the fields than in conferences," he said.',
  image: 'https://www.agriculture.go.ug/wp-content/uploads/bb/cache/BLA_1927-264x300-circle.jpg',
  alt: 'Minister Frank Tumwebaze addressing farmers and ministry officials at an agricultural event'
},
{
  id: 3,
  title: 'Uganda Achieves Record Coffee Export Earnings of USD 1.07 Billion',
  date: 'March 10, 2026',
  category: 'News Update',
  excerpt: 'Uganda has achieved record coffee export earnings of USD 1.07 billion in the 2024/25 financial year, representing a 23% increase from the previous year. The achievement is attributed to improved quality standards and expanded market access facilitated by UCDA.',
  image: 'https://www.agriculture.go.ug/wp-content/uploads/2020/11/ghfk.jpg',
  alt: 'Ugandan coffee farmers harvesting and sorting coffee beans on a coffee plantation'
},
{
  id: 4,
  title: 'MAAIF Issues Advisory on Fall Armyworm Management for Maize Farmers',
  date: 'February 22, 2026',
  category: 'Advisory',
  excerpt: 'The Directorate of Crop Resources has issued an urgent advisory to maize farmers across Uganda on the management of Fall Armyworm (Spodoptera frugiperda) following increased reports of crop damage in the eastern and northern regions.',
  image: 'https://www.agriculture.go.ug/wp-content/uploads/2020/11/fgh.jpg',
  alt: 'Agricultural extension officer inspecting maize crop for fall armyworm damage in Uganda field'
},
{
  id: 5,
  title: 'New Animal Feeds Act 2024 Comes into Force — Key Changes for Livestock Farmers',
  date: 'February 5, 2026',
  category: 'Regulatory Update',
  excerpt: 'The Animal Feeds Act 2024 has officially come into force, introducing new quality standards and registration requirements for animal feed manufacturers and distributors in Uganda. All existing operators have a 6-month transition period to comply.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/fisheries.jpg',
  alt: 'Livestock farmers in Uganda feeding cattle with regulated animal feeds at a modern farm'
},
{
  id: 6,
  title: 'MAAIF and FAO Sign Agreement to Strengthen Food Security in Karamoja Region',
  date: 'January 18, 2026',
  category: 'Partnership',
  excerpt: 'The Ministry of Agriculture, Animal Industry and Fisheries has signed a cooperation agreement with the Food and Agriculture Organization (FAO) to implement a USD 8 million food security and nutrition program in the Karamoja sub-region.',
  image: 'http://agriculture.go.ug/wp-content/uploads/2019/05/extension-services.jpg',
  alt: 'MAAIF and FAO officials signing a food security cooperation agreement in Kampala Uganda'
}];


const newsletters = [
{ title: 'MAAIF Newsletter — Q1 2026', date: 'March 2026', pages: '24 pages', size: '3.2 MB' },
{ title: 'MAAIF Newsletter — Q4 2025', date: 'December 2025', pages: '28 pages', size: '4.1 MB' },
{ title: 'MAAIF Newsletter — Q3 2025', date: 'September 2025', pages: '22 pages', size: '2.9 MB' },
{ title: 'MAAIF Newsletter — Q2 2025', date: 'June 2025', pages: '26 pages', size: '3.7 MB' }];


const events = [
{ title: 'National Farmers Day (Thanksgiving)', date: 'June 3, 2026', location: 'Kabale District, Uganda', type: 'National Event' },
{ title: 'Uganda Agri-Business Summit 2026', date: 'May 20–21, 2026', location: 'Kampala Serena Hotel', type: 'Conference' },
{ title: 'MAAIF Quarterly Stakeholder Meeting', date: 'May 8, 2026', location: 'Ministry HQ, Entebbe', type: 'Meeting' },
{ title: 'East Africa Agricultural Trade Fair', date: 'July 10–14, 2026', location: 'Lugogo Show Grounds, Kampala', type: 'Exhibition' }];


const categoryColors: Record<string, string> = {
  'Press Release': 'bg-primary/10 text-primary',
  'News Update': 'bg-secondary/10 text-secondary',
  'Advisory': 'bg-accent/10 text-accent',
  'Regulatory Update': 'bg-purple-100 text-purple-700',
  'Partnership': 'bg-sky-100 text-sky-700'
};

export default function MediaPage() {
  return (
    <main className="min-h-screen bg-background overflow-x-hidden">
      <Header />

      {/* Page Hero */}
      <section className="pt-36 pb-16 px-6 lg:px-16 bg-gradient-to-b from-primary/5 to-background">
        <div className="max-w-[1400px] mx-auto">
          <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-4">
            Media Centre
          </span>
          <h1 className="font-serif-display text-5xl md:text-6xl font-medium text-foreground leading-tight tracking-tight mb-4">
            News &amp; Media
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl leading-relaxed">
            Stay informed with the latest press releases, news updates, advisories, newsletters, and events from the Ministry of Agriculture, Animal Industry and Fisheries.
          </p>
        </div>
      </section>

      {/* Featured Article */}
      <section className="py-12 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <div className="rounded-3xl overflow-hidden border border-border bg-card grid grid-cols-1 lg:grid-cols-2 shadow-lg">
            <div className="h-72 lg:h-auto overflow-hidden">
              <AppImage
                src="https://www.agriculture.go.ug/wp-content/uploads/2021/06/FROST-20-of-149.jpg"
                alt="MAAIF officials at the launch of Uganda Climate Smart Agricultural Transformation Project ceremony"
                width={700}
                height={500}
                className="w-full h-full object-cover" />

            </div>
            <div className="p-8 lg:p-10 flex flex-col justify-center">
              <div className="flex items-center gap-3 mb-4">
                <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold">Featured</span>
                <span className="text-muted text-xs">April 15, 2026</span>
              </div>
              <h2 className="font-serif-display text-3xl font-medium text-foreground leading-tight mb-4">
                MAAIF Launches Uganda Climate Smart Agricultural Transformation Project (UCSATP)
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6">
                The Ministry of Agriculture, Animal Industry and Fisheries has officially launched the Uganda Climate Smart Agricultural Transformation Project, a USD 150 million initiative funded by the World Bank to support climate-resilient agriculture across 60 districts.
              </p>
              <a href="#" className="inline-flex items-center gap-2 text-primary font-semibold text-sm hover:gap-3 transition-all">
                Read Full Article
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Press Releases Grid */}
      <section className="py-12 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-serif-display text-3xl font-medium text-foreground">Press Releases &amp; News</h2>
            <a href="#" className="text-primary text-sm font-semibold hover:underline">View All</a>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pressReleases.slice(1).map((article) =>
            <article key={article.id} className="rounded-3xl overflow-hidden border border-border bg-card hover:shadow-lg transition-all hover:-translate-y-1 group">
                <div className="h-48 overflow-hidden">
                  <AppImage
                  src={article.image}
                  alt={article.alt}
                  width={500}
                  height={192}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />

                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${categoryColors[article.category] || 'bg-muted/20 text-muted'}`}>
                      {article.category}
                    </span>
                    <span className="text-muted text-xs">{article.date}</span>
                  </div>
                  <h3 className="font-semibold text-foreground text-base leading-tight mb-2 line-clamp-2">{article.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed line-clamp-3 mb-4">{article.excerpt}</p>
                  <a href="#" className="inline-flex items-center gap-1.5 text-primary text-sm font-semibold hover:gap-2.5 transition-all">
                    Read More
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </a>
                </div>
              </article>
            )}
          </div>
        </div>
      </section>

      {/* Newsletters + Events */}
      <section className="py-16 px-6 lg:px-16 bg-gradient-to-b from-background to-primary/5">
        <div className="max-w-[1400px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10">

          {/* Newsletters */}
          <div>
            <h2 className="font-serif-display text-3xl font-medium text-foreground mb-6">MAAIF Newsletters</h2>
            <div className="space-y-3">
              {newsletters.map((nl) =>
              <div key={nl.title} className="flex items-center justify-between p-4 rounded-2xl bg-card border border-border hover:border-primary/30 hover:shadow-sm transition-all group">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">{nl.title}</p>
                      <p className="text-muted text-xs">{nl.date} · {nl.pages} · {nl.size}</p>
                    </div>
                  </div>
                  <a href="#" className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-all flex-shrink-0" aria-label={`Download ${nl.title}`}>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                    </svg>
                  </a>
                </div>
              )}
            </div>
          </div>

          {/* Upcoming Events */}
          <div>
            <h2 className="font-serif-display text-3xl font-medium text-foreground mb-6">Upcoming Events</h2>
            <div className="space-y-3">
              {events.map((event) =>
              <div key={event.title} className="p-5 rounded-2xl bg-card border border-border hover:border-primary/30 hover:shadow-sm transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center flex-shrink-0">
                      <svg className="w-5 h-5 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-semibold">{event.type}</span>
                      </div>
                      <h3 className="font-semibold text-foreground text-sm mb-1">{event.title}</h3>
                      <p className="text-muted text-xs">{event.date}</p>
                      <p className="text-muted-foreground text-xs flex items-center gap-1 mt-0.5">
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        {event.location}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Subscribe */}
      <section className="py-16 px-6 lg:px-16 bg-primary text-white">
        <div className="max-w-[1400px] mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <h2 className="font-serif-display text-3xl font-medium mb-2">Subscribe to MAAIF Newsletter</h2>
            <p className="text-white/70">Get the latest agricultural news, advisories, and updates delivered to your inbox.</p>
          </div>
          <form className="flex gap-3 w-full md:w-auto" onSubmit={(e) => e.preventDefault()}>
            <input
              type="email"
              placeholder="Your email address"
              className="flex-1 md:w-72 px-4 py-3 rounded-full bg-white/10 border border-white/20 text-white placeholder-white/40 text-sm focus:outline-none focus:border-white/50" />

            <button type="submit" className="px-6 py-3 rounded-full bg-white text-primary font-semibold text-sm hover:bg-white/90 transition-colors flex-shrink-0">
              Subscribe
            </button>
          </form>
        </div>
      </section>

      <Footer />
    </main>);

}