import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

const categories = [
  {
    id: 'general',
    title: 'General Import & Export Guidelines',
    icon: (
      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
    color: 'bg-emerald-50 border-emerald-100',
    iconBg: 'bg-primary/10 text-primary',
    description: 'Comprehensive guidelines for importing and exporting agricultural commodities in and out of Uganda.',
    items: [
      'All agricultural imports and exports require permits issued by MAAIF',
      'Importers must obtain a valid Import Permit before shipment',
      'Exporters must obtain a Phytosanitary or Veterinary Certificate',
      'All consignments are subject to inspection at point of entry/exit',
      'Prohibited items include certain invasive species and restricted chemicals',
      'Transit goods must be accompanied by valid transit documents',
    ],
  },
  {
    id: 'plants',
    title: 'Plants & Plant Products',
    icon: (
      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
      </svg>
    ),
    color: 'bg-green-50 border-green-100',
    iconBg: 'bg-secondary/10 text-secondary',
    description: 'Phytosanitary requirements and procedures for importing and exporting plants, seeds, and plant-based products.',
    items: [
      'Phytosanitary Certificate required for all plant exports',
      'Import Permit required for all plant imports',
      'Seeds must be certified and accompanied by seed health certificate',
      'Inspection by Directorate of Crop Resources (DCR) mandatory',
      'Fumigation may be required for certain commodities',
      'Prohibited: plants from countries with active pest outbreaks',
    ],
  },
  {
    id: 'fisheries',
    title: 'Online Certification for Fisheries Exports',
    icon: (
      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 12c-1.5 2.5-4.5 4-7.5 4S7.5 14.5 6 12c1.5-2.5 4.5-4 7.5-4s6 1.5 7.5 4z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 12h3m15 0h-3" />
      </svg>
    ),
    color: 'bg-sky-50 border-sky-100',
    iconBg: 'bg-sky-500/10 text-sky-600',
    description: 'Digital certification system for fish and fisheries products destined for export markets, including EU and Asian markets.',
    items: [
      'Apply online via the MAAIF Fisheries Export Portal',
      'Health Certificate required for EU market access',
      'Catch Certificate required for all marine and freshwater fish',
      'Processing facilities must be EU-approved and regularly inspected',
      'Cold chain documentation required for chilled/frozen products',
      'Turnaround time: 3–5 working days for standard applications',
    ],
  },
  {
    id: 'animals',
    title: 'Import/Export of Animals & Animal Products',
    icon: (
      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
    color: 'bg-amber-50 border-amber-100',
    iconBg: 'bg-accent/10 text-accent',
    description: 'Veterinary requirements and procedures for the movement of live animals, meat, dairy, and other animal-derived products.',
    items: [
      'Veterinary Import Permit required for all live animal imports',
      'Animals must originate from disease-free countries/zones',
      'Quarantine period of 30 days required for imported livestock',
      'Veterinary Health Certificate required for animal product exports',
      'Meat exports require HACCP-certified processing facilities',
      'Dairy products must meet Uganda National Bureau of Standards (UNBS) requirements',
    ],
  },
];

const steps = [
  { step: '01', title: 'Register on the Portal', desc: 'Create an account on the MAAIF Online Services Portal at services.agriculture.go.ug' },
  { step: '02', title: 'Submit Application', desc: 'Complete the relevant application form and attach all required supporting documents' },
  { step: '03', title: 'Pay Application Fee', desc: 'Pay the prescribed fee via mobile money, bank transfer, or at any MAAIF office' },
  { step: '04', title: 'Inspection & Review', desc: 'MAAIF officers will inspect the consignment and review submitted documents' },
  { step: '05', title: 'Certificate Issued', desc: 'Upon approval, your certificate is issued digitally and can be downloaded from the portal' },
];

const contacts = [
  { dept: 'Directorate of Crop Resources (DCR)', role: 'Plants & Plant Products', email: 'dcr@agriculture.go.ug', tel: '+256 414 320 004' },
  { dept: 'Directorate of Animal Resources (DAR)', role: 'Animals & Animal Products', email: 'dar@agriculture.go.ug', tel: '+256 414 320 005' },
  { dept: 'Directorate of Fisheries Resources (DFR)', role: 'Fisheries Exports', email: 'dfr@agriculture.go.ug', tel: '+256 414 320 006' },
];

export default function ImportExportPage() {
  return (
    <main className="min-h-screen bg-background overflow-x-hidden">
      <Header />
      {/* Page Hero */}
      <section className="pt-36 pb-20 px-6 lg:px-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-background to-accent/5" />
        <div className="absolute top-20 right-0 w-96 h-96 rounded-full bg-accent/5 blur-3xl" />
        <div className="max-w-[1400px] mx-auto relative">
          <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-5">
            Trade Facilitation
          </span>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="font-serif-display text-5xl md:text-6xl font-medium text-foreground leading-tight tracking-tight mb-6">
                Import &amp; Export<br />
                <span className="text-primary">Certification</span>
              </h1>
              <p className="text-muted-foreground text-lg leading-relaxed mb-8 max-w-xl">
                MAAIF facilitates the import and export of agricultural commodities through a streamlined certification and permitting system. All agricultural trade must comply with Uganda&apos;s phytosanitary and veterinary regulations.
              </p>
              <div className="flex flex-wrap gap-3">
                <a href="#categories" className="px-6 py-3 rounded-full bg-primary text-white font-semibold text-sm hover:bg-primary/90 transition-colors">
                  View Requirements
                </a>
                <Link href="/services" className="px-6 py-3 rounded-full border border-border text-foreground font-semibold text-sm hover:border-primary/40 hover:text-primary transition-colors">
                  Submit Inquiry
                </Link>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { label: 'Certificates Issued Annually', value: '12,000+', color: 'bg-primary/10 border-primary/15' },
                { label: 'Export Markets Served', value: '45+', color: 'bg-accent/10 border-accent/15' },
                { label: 'Processing Time', value: '3–5 Days', color: 'bg-secondary/10 border-secondary/15' },
                { label: 'Online Applications', value: '100%', color: 'bg-sky-100 border-sky-200' },
              ]?.map((stat) => (
                <div key={stat?.label} className={`rounded-2xl p-5 border ${stat?.color}`}>
                  <p className="text-2xl font-bold text-foreground mb-1">{stat?.value}</p>
                  <p className="text-muted-foreground text-xs leading-tight">{stat?.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      {/* Categories */}
      <section id="categories" className="py-20 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <div className="mb-12">
            <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-4">
              Commodity Categories
            </span>
            <h2 className="font-serif-display text-4xl font-medium text-foreground leading-tight">
              Import &amp; Export Guidelines
            </h2>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {categories?.map((cat) => (
              <div key={cat?.id} className={`rounded-3xl border p-8 ${cat?.color}`}>
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-5 ${cat?.iconBg}`}>
                  {cat?.icon}
                </div>
                <h3 className="font-semibold text-foreground text-xl mb-2">{cat?.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-6">{cat?.description}</p>
                <ul className="space-y-2.5">
                  {cat?.items?.map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-foreground">
                      <span className="mt-0.5 w-5 h-5 rounded-full bg-primary/15 text-primary flex items-center justify-center flex-shrink-0">
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                        </svg>
                      </span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* Application Process */}
      <section className="py-20 px-6 lg:px-16 bg-gradient-to-b from-background to-primary/5">
        <div className="max-w-[1400px] mx-auto">
          <div className="mb-12 text-center">
            <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-4">
              How It Works
            </span>
            <h2 className="font-serif-display text-4xl font-medium text-foreground leading-tight">
              Application Process
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {steps?.map((step, i) => (
              <div key={step?.step} className="relative">
                <div className="rounded-2xl bg-card border border-border p-5 h-full hover:border-primary/30 hover:shadow-sm transition-all">
                  <span className="text-4xl font-bold text-primary/15 font-serif-display block mb-3">{step?.step}</span>
                  <h3 className="font-semibold text-foreground text-sm mb-2">{step?.title}</h3>
                  <p className="text-muted-foreground text-xs leading-relaxed">{step?.desc}</p>
                </div>
                {i < steps?.length - 1 && (
                  <div className="hidden lg:flex absolute top-1/2 -right-2 z-10 w-4 h-4 items-center justify-center">
                    <svg className="w-4 h-4 text-primary/40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* Contact Departments */}
      <section className="py-20 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <div className="mb-10">
            <h2 className="font-serif-display text-3xl font-medium text-foreground">Contact the Relevant Directorate</h2>
            <p className="text-muted-foreground mt-2">Reach out to the appropriate directorate for specific import/export queries.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {contacts?.map((c) => (
              <div key={c?.dept} className="rounded-3xl bg-card border border-border p-6 hover:border-primary/30 hover:shadow-sm transition-all">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                  <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                </div>
                <h3 className="font-semibold text-foreground text-sm mb-1">{c?.dept}</h3>
                <p className="text-muted text-xs mb-3">{c?.role}</p>
                <a href={`mailto:${c?.email}`} className="block text-primary text-sm font-medium hover:underline mb-1">{c?.email}</a>
                <p className="text-muted-foreground text-sm">{c?.tel}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
