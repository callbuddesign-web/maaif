import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const keyIndicators = [
  { label: 'Agriculture Share of GDP', value: '24.1%', change: '+1.2%', trend: 'up', desc: 'FY 2024/25' },
  { label: 'Agricultural Labour Force', value: '65%', change: '+0.5%', trend: 'up', desc: 'of working population' },
  { label: 'Total Arable Land', value: '6.8M ha', change: '+0.3M', trend: 'up', desc: 'under cultivation' },
  { label: 'Coffee Export Earnings', value: 'USD 1.07B', change: '+23%', trend: 'up', desc: 'FY 2024/25 record' },
  { label: 'Fish Export Value', value: 'USD 185M', change: '+8%', trend: 'up', desc: 'FY 2024/25' },
  { label: 'Livestock Population', value: '14.2M', change: '+4%', trend: 'up', desc: 'cattle heads' },
];

const cropProduction = [
  { crop: 'Maize', production: '4.8M MT', area: '1.2M ha', yield: '4.0 MT/ha', trend: 'up' },
  { crop: 'Cassava', production: '6.2M MT', area: '0.8M ha', yield: '7.8 MT/ha', trend: 'up' },
  { crop: 'Beans', production: '0.9M MT', area: '0.6M ha', yield: '1.5 MT/ha', trend: 'stable' },
  { crop: 'Bananas (Matoke)', production: '3.1M MT', area: '0.5M ha', yield: '6.2 MT/ha', trend: 'up' },
  { crop: 'Coffee (Arabica & Robusta)', production: '0.7M MT', area: '0.4M ha', yield: '1.75 MT/ha', trend: 'up' },
  { crop: 'Rice', production: '0.3M MT', area: '0.15M ha', yield: '2.0 MT/ha', trend: 'up' },
  { crop: 'Sorghum', production: '0.6M MT', area: '0.4M ha', yield: '1.5 MT/ha', trend: 'stable' },
  { crop: 'Sunflower', production: '0.2M MT', area: '0.18M ha', yield: '1.1 MT/ha', trend: 'up' },
];

const livestockData = [
  { category: 'Cattle', population: '14.2M', production: 'Beef & Dairy', value: 'UGX 3.2T' },
  { category: 'Goats', population: '16.8M', production: 'Meat & Milk', value: 'UGX 1.1T' },
  { category: 'Sheep', population: '4.5M', production: 'Meat & Wool', value: 'UGX 0.4T' },
  { category: 'Pigs', population: '5.2M', production: 'Pork', value: 'UGX 0.8T' },
  { category: 'Poultry', population: '48.6M', production: 'Eggs & Meat', value: 'UGX 1.5T' },
];

const exportData = [
  { commodity: 'Coffee', value: 'USD 1,070M', volume: '6.8M 60kg bags', markets: 'EU, USA, Asia', share: '52%' },
  { commodity: 'Fish & Fish Products', value: 'USD 185M', volume: '42,000 MT', markets: 'EU, Middle East', share: '9%' },
  { commodity: 'Tea', value: 'USD 95M', volume: '68,000 MT', markets: 'Pakistan, UK, Kenya', share: '5%' },
  { commodity: 'Vanilla', value: 'USD 78M', volume: '320 MT', markets: 'USA, EU, Japan', share: '4%' },
  { commodity: 'Flowers & Horticulture', value: 'USD 65M', volume: '18,000 MT', markets: 'EU, Middle East', share: '3%' },
  { commodity: 'Maize & Grain', value: 'USD 55M', volume: '180,000 MT', markets: 'EAC Region', share: '3%' },
];

const reports = [
  { title: 'Uganda Agriculture Sector Statistical Abstract 2024', year: '2024', type: 'Statistical Abstract', size: '12.4 MB' },
  { title: 'Crop Production Statistics Report 2023/24', year: '2024', type: 'Production Report', size: '5.8 MB' },
  { title: 'Livestock Census Report 2021', year: '2021', type: 'Census', size: '9.1 MB' },
  { title: 'Fish Production and Trade Statistics 2024', year: '2024', type: 'Trade Report', size: '3.7 MB' },
  { title: 'Agricultural Trade Statistics Bulletin Q4 2025', year: '2025', type: 'Trade Bulletin', size: '2.1 MB' },
  { title: 'Agro-Meteorological Seasonal Forecast 2025A', year: '2025', type: 'Forecast', size: '1.8 MB' },
];

export default function StatisticsPage() {
  return (
    <main className="min-h-screen bg-background overflow-x-hidden">
      <Header />
      {/* Page Hero */}
      <section className="pt-36 pb-16 px-6 lg:px-16 bg-gradient-to-b from-primary/5 to-background">
        <div className="max-w-[1400px] mx-auto">
          <span className="inline-block px-4 py-1.5 rounded-full border border-primary/20 text-xs font-semibold text-primary tracking-widest uppercase mb-4">
            Data & Analytics
          </span>
          <h1 className="font-serif-display text-5xl md:text-6xl font-medium text-foreground leading-tight tracking-tight mb-4">
            Sector Statistics
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl leading-relaxed">
            Comprehensive agricultural data, production figures, livestock census, trade statistics, and sector performance indicators for Uganda&apos;s agricultural sector.
          </p>
        </div>
      </section>
      {/* Key Indicators */}
      <section className="py-12 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <h2 className="font-serif-display text-3xl font-medium text-foreground mb-6">Key Sector Indicators</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {keyIndicators?.map((ind) => (
              <div key={ind?.label} className="rounded-2xl bg-card border border-border p-5 hover:border-primary/30 hover:shadow-sm transition-all">
                <div className="flex items-center gap-1.5 mb-2">
                  <span className={`text-xs font-semibold ${ind?.trend === 'up' ? 'text-green-600' : 'text-muted'}`}>
                    {ind?.trend === 'up' ? '▲' : '—'} {ind?.change}
                  </span>
                </div>
                <p className="text-2xl font-bold text-foreground mb-1">{ind?.value}</p>
                <p className="text-xs font-semibold text-foreground leading-tight mb-0.5">{ind?.label}</p>
                <p className="text-xs text-muted">{ind?.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* Crop Production */}
      <section className="py-12 px-6 lg:px-16 bg-gradient-to-b from-background to-primary/3">
        <div className="max-w-[1400px] mx-auto">
          <h2 className="font-serif-display text-3xl font-medium text-foreground mb-6">Crop Production Statistics (2024/25)</h2>
          <div className="rounded-3xl overflow-hidden border border-border bg-card">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-primary/5 border-b border-border">
                    <th className="text-left px-6 py-4 text-xs font-bold text-muted uppercase tracking-widest">Crop</th>
                    <th className="text-left px-6 py-4 text-xs font-bold text-muted uppercase tracking-widest">Production</th>
                    <th className="text-left px-6 py-4 text-xs font-bold text-muted uppercase tracking-widest">Area Harvested</th>
                    <th className="text-left px-6 py-4 text-xs font-bold text-muted uppercase tracking-widest">Yield</th>
                    <th className="text-left px-6 py-4 text-xs font-bold text-muted uppercase tracking-widest">Trend</th>
                  </tr>
                </thead>
                <tbody>
                  {cropProduction?.map((row, i) => (
                    <tr key={row?.crop} className={`border-b border-border last:border-0 hover:bg-primary/3 transition-colors ${i % 2 === 0 ? '' : 'bg-background/50'}`}>
                      <td className="px-6 py-4 font-semibold text-foreground text-sm">{row?.crop}</td>
                      <td className="px-6 py-4 text-foreground text-sm">{row?.production}</td>
                      <td className="px-6 py-4 text-muted-foreground text-sm">{row?.area}</td>
                      <td className="px-6 py-4 text-muted-foreground text-sm">{row?.yield}</td>
                      <td className="px-6 py-4">
                        <span className={`text-xs font-semibold ${row?.trend === 'up' ? 'text-green-600' : 'text-muted'}`}>
                          {row?.trend === 'up' ? '▲ Increasing' : '— Stable'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
      {/* Livestock */}
      <section className="py-12 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <h2 className="font-serif-display text-3xl font-medium text-foreground mb-6">Livestock Population (2024)</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {livestockData?.map((item) => (
              <div key={item?.category} className="rounded-2xl bg-card border border-border p-5 hover:border-primary/30 hover:shadow-sm transition-all">
                <h3 className="font-bold text-foreground text-lg mb-1">{item?.population}</h3>
                <p className="font-semibold text-foreground text-sm mb-1">{item?.category}</p>
                <p className="text-muted text-xs mb-2">{item?.production}</p>
                <p className="text-primary text-xs font-semibold">{item?.value} annual value</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* Export Statistics */}
      <section className="py-12 px-6 lg:px-16 bg-gradient-to-b from-background to-primary/5">
        <div className="max-w-[1400px] mx-auto">
          <h2 className="font-serif-display text-3xl font-medium text-foreground mb-6">Agricultural Export Statistics (2024/25)</h2>
          <div className="rounded-3xl overflow-hidden border border-border bg-card">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-primary/5 border-b border-border">
                    <th className="text-left px-6 py-4 text-xs font-bold text-muted uppercase tracking-widest">Commodity</th>
                    <th className="text-left px-6 py-4 text-xs font-bold text-muted uppercase tracking-widest">Export Value</th>
                    <th className="text-left px-6 py-4 text-xs font-bold text-muted uppercase tracking-widest">Volume</th>
                    <th className="text-left px-6 py-4 text-xs font-bold text-muted uppercase tracking-widest">Key Markets</th>
                    <th className="text-left px-6 py-4 text-xs font-bold text-muted uppercase tracking-widest">Share of Agri Exports</th>
                  </tr>
                </thead>
                <tbody>
                  {exportData?.map((row, i) => (
                    <tr key={row?.commodity} className={`border-b border-border last:border-0 hover:bg-primary/3 transition-colors ${i % 2 === 0 ? '' : 'bg-background/50'}`}>
                      <td className="px-6 py-4 font-semibold text-foreground text-sm">{row?.commodity}</td>
                      <td className="px-6 py-4 text-primary font-semibold text-sm">{row?.value}</td>
                      <td className="px-6 py-4 text-muted-foreground text-sm">{row?.volume}</td>
                      <td className="px-6 py-4 text-muted-foreground text-sm">{row?.markets}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-border rounded-full h-1.5 max-w-[80px]">
                            <div className="bg-primary h-1.5 rounded-full" style={{ width: row?.share }} />
                          </div>
                          <span className="text-xs font-semibold text-foreground">{row?.share}</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
      {/* Statistical Reports */}
      <section className="py-16 px-6 lg:px-16">
        <div className="max-w-[1400px] mx-auto">
          <h2 className="font-serif-display text-3xl font-medium text-foreground mb-6">Download Statistical Reports</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {reports?.map((report) => (
              <div key={report?.title} className="flex items-start gap-4 p-5 rounded-2xl bg-card border border-border hover:border-primary/30 hover:shadow-sm transition-all group">
                <div className="w-10 h-12 rounded-xl bg-primary/8 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/15 transition-colors">
                  <svg className="w-5 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground text-sm leading-tight mb-1.5 line-clamp-2">{report?.title}</h3>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-semibold">{report?.type}</span>
                    <span className="text-muted text-xs">{report?.year} · {report?.size}</span>
                  </div>
                </div>
                <a
                  href="#"
                  className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-all flex-shrink-0 mt-0.5"
                  aria-label={`Download ${report?.title}`}
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
